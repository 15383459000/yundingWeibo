create procedure trans(IN id0 int, IN id1 int, IN transMoney double)
begin
  update account_book set money = money - transMoney where id = id0;
  update account_book set money = money + transMoney where id = id1;
end;

