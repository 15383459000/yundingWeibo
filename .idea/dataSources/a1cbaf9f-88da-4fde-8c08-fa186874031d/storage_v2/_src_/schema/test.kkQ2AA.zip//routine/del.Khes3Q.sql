create procedure del(IN p_id int)
BEGIN
  DELETE FROM account_book WHERE id=p_id;
END;

