create procedure refer(IN pid int, OUT name char, OUT money char)
begin
  set name = (select (name,id) from account_book where pid = id);
  
end;

